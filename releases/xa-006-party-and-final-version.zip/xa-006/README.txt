xa-006: Quick fix

This is a demo we made since we where going to Edison 2016 and thought we ought to release something. It was mostly made during the two party days.

The demo is made using three.js for WebGL and GNU rocket for music syncing.

We developed it in Google Chrome, but it has also been known to work in Firefox.

Files:
- xa-006-final-version.html: Final version. We spent another day after the deadline to make the demo more complete. It's about twice as long and has credits.
- xa-006-party-version.html: The version we released at the party. Just barely working...

Credits:
- Code and music syncing by danter and trejs
- Music by Yirsi @ SoundCloud. https://soundcloud.com/yirsi/unknown-world
